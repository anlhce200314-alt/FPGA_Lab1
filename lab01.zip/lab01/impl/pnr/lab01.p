`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
FdVdVBlVmkI6ukxD1jC3MzYh7pp4FBb6+9U1gckOhjAxI4YkBUTZDgEdNBfhH92mfrhY92nxmTIF
tIDjooplZQ4iDKhvX87NtXvR44GrIPV8bzsT/ylcgOxNmL1fUdaP521qDDTlKPjjtvI20VA+G7lR
TdSY75zvYquheJDV5waJhACvE0vvKNnPMcJjv+/nFKnakw1TQGIkITIo5PPPj6JD6LDvVE870BJN
pt4SAIo+B7SxmD9HJnAj2j2ku1idNBxCov2WjWhBnZtZRA/oiWVKgX6flw7OnL6IVw8U2SnUvKYB
q5Go82GWiQSytTQrnZy7NQb+lnvHGb3s4zbgPw==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=352)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
3QKk/Oc8Kgkkoe8k2ayPRh1zpI4cajZ5MBC4yJeuSGouq+LXV8tzgWljescfqlEqKYP4BKrW2t2B
bnMVc8c1AgMeBSCiLNKiBdTajDSaWEshr8Glqn0OmtjbpMAT2MKmW6eRtGK4fD+683dXb8YEZclW
X1TMU+x40J1Z5ziyXVwzDASlX7S4OaUoC8ypCwpa1Ci9Bw7u81YMqzO+vmvhNmY7vbcUTBH6ddx2
XUE/QkgENTqi4DIS7edt0qdqu+ylHI95Wfzrujt/u1TsAI0G6tGFnCbx1JEHb5dxPCK1pMi2LQ3H
Hbb+C4J5xbbVE4gxZ14A/adVZQnJcMr0hqzStxTjxCj+o2DKEDaBjDchw8Tt55iZ66uleKeN3dD5
WL8wvpxGL4JSlc1To4KZSfrMlgRJJvaood8JDzLtgclupQXs5D60mM0rY/NyHNyT2atmXVLGWOp1
4JgM1QgvC9pd4w==
`pragma protect end_protected
