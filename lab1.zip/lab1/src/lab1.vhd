library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity lab1 is
  port (
    bt1 : in  std_logic;
    bt2 : in  std_logic;
    bt3 : in  std_logic;

    led1 : out std_logic;
    led2 : out std_logic;
    led3 : out std_logic
  );
end entity lab1;

architecture logic of lab1 is
begin
    led1 <= bt1;
    led2 <= bt2;
    led3 <= bt3;
end architecture logic;
