`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
inDj7dLNuk9Cam0Ur6/NWsYcYjPv5qW1ileFFow+k7IeVDEZRNymRRwfzDLkKpye4a+xyec3fnHe
tbtwPaHEGbyatvPaSeCRQehewp86kGnVMP+ObNv/pTiFcUhUblVo/I8dFneXmNCOF1WJ2B5SIhVv
GFJIim7g+t9YCUo8ppGG0AlZnF43wKsm3RuPznt49/Oc63cwkCsaM7ELgEfJniZeAcmU52GOk4xT
y1E9AYSll5kC6b2whG2iMoM4qwrquCfb+LeDBs0U3hs1m9rbc+WLKdScFpQe5dcRTqIEj2lHhDXz
e6A5e73alMQqwMgnpbxgFmkfwbUBzDnW8iZe+w==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=352)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
e2tvGmBprfZLa6FuLDBeV7qRDcVgMSZF2CC9WkSBr/3098YD1yUfVYsGnsTKVfNzuo6r/XDYU6V4
I/O7Bsl1vJ3CkieKpGxYGiHWhSbaT+kZ7AMsudDuC7JaYmg7eqKkY3l9qh5541cJo+z+Mr3g+4PW
AvecrjP1WHv+x5re7guYRi6pBc8yOG3KvlNWltGBeBH2DnPD5ppEuQoJO5DYW42JACB3KXjAqKqM
GOPKIuvfkFKglE5h6DdaJAPPeNJYHmeelwk+MDdhvGaua1uQkPTD0+FlIKiowh+rFyBis2rJVjLd
QbjUN6s+Eo1cMmDQ94ty5WE/wAIsRjuOClZc1qljzTZ1yUzD5UIAZVgKSF8BWmtdD9+5ZB+zCpn9
CmK7yf/JEqnSC/haarBCnBhEfXE4z03kbl0c9Engfiy4oTPwGEuyTXkOyMFeJkba7PU7AeO2Dg9R
xGf8wLsKH9HpHw==
`pragma protect end_protected
